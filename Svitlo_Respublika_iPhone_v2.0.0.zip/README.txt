Світло Республіка API v2.0.0
1. Отримайте API-токен: https://chatbot.respublika.pp.ua/resident/
2. Перемістіть INSTALL.js у iCloud Drive/Scriptable і запустіть.
3. Виберіть адресу та вставте персональний токен.
4. Налаштуйте тільки Telegram-автоматизацію імпорту графіків.
Історію JSON не видаляйте.
